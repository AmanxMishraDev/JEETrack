import { mapPwAttempt } from './pw-mapper.js';
import { buildOptimaPayload, MAX_QUESTIONS, DEFAULTS, isLive, syncFromSite, loadProfileName, fetchJobStatus, buildTestLog, warmUp } from './optima.js';
import { checkLog } from './sender.js';

const $ = id => document.getElementById(id);
const say = (id, text, cls = 'muted') => { const el = $(id); el.textContent = text; el.className = 'msg ' + cls; };
const getSettings = async () => ({ ...DEFAULTS, ...((await chrome.storage.local.get('settings')).settings ?? {}) });
const activeTab = async () => (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
const mappingFromUrl = url => { try { const u = new URL(url); return u.searchParams.get('testMappingId') ?? u.searchParams.get('testMapId'); } catch { return null; } };

let captures = {}, mapped = null, shown = null, optima = null, _logFor = null, _logWarn = [];

// ---------------- the student (name as shown in the JEETrack app; the email is never displayed) ----------------
async function autoConnect() {
  const { session } = await chrome.storage.local.get('session');
  if (!isLive(session)) await syncFromSite(await getSettings()).catch(() => null); // reads the logged-in JEETrack tab, if one is open
  await loadProfileName(await getSettings()).catch(() => null);
}
async function refreshWho() {
  const { session } = await chrome.storage.local.get('session'), ok = isLive(session);
  const name = ok ? (session.name || 'Student') : 'Not connected';
  $('sname').textContent = name;
  $('avatar').textContent = ok ? ([...name.trim()][0] ?? 'S').toUpperCase() : '?';
  $('conn').className = 'conn' + (ok ? ' on' : '');
  $('connt').textContent = ok ? 'Connected to JEETrack' : 'Log in to JEETrack in this browser';
  $('openjt').hidden = ok;
}
$('openjt').onclick = () => chrome.tabs.create({ url: 'https://www.jeetrack.in/' });

// ---------------- which test ----------------
async function init() {
  ({ captures = {} } = await chrome.storage.local.get('captures'));
  const { settings = {} } = await chrome.storage.local.get('settings'); $('consent').checked = !!settings.consent;
  const ids = Object.keys(captures).filter(id => captures[id].q).sort((a, b) => captures[b].t - captures[a].t);
  const tab = await activeTab().catch(() => null), want = tab ? mappingFromUrl(tab.url) : null;
  if (!ids.length) {
    $('empty').hidden = false; $('main').hidden = true;
    $('emptytxt').textContent = want ? 'This test page is open but nothing was captured yet. Press Refresh.' : 'Open your PW test result page. It is picked up automatically.';
    return;
  }
  $('empty').hidden = true; $('main').hidden = false;
  $('pick').innerHTML = ''; $('pick').hidden = ids.length < 2;
  for (const id of ids) { const o = document.createElement('option'); o.value = id; o.textContent = captures[id].q?.data?.test?.name ?? id; $('pick').append(o); }
  const first = ids.includes(shown) ? shown : ids.includes(want) ? want : ids[0];
  $('pick').value = first; $('pick').onchange = () => show($('pick').value);
  show(first, want && !ids.includes(want) ? want : null);
}

function chip(text, cls = '') { const s = document.createElement('span'); s.className = 'chip ' + cls; s.textContent = text; return s; }

function show(id, missingForTab = null) {
  shown = id; mapped = null; optima = null;
  const cap = captures[id];
  try { mapped = mapPwAttempt(cap.q, id, cap.my ?? null); }
  catch { $('empty').hidden = false; $('main').hidden = true; $('emptytxt').textContent = 'Could not read this test. Press Refresh.'; return; }
  const c = mapped.counts;
  $('tname').textContent = mapped.name;
  $('tscore').textContent = mapped.score ?? '–'; $('tof').textContent = mapped.totalMarks ? `/ ${mapped.totalMarks}` : '';
  $('tstats').replaceChildren(chip(`${mapped.questions.length} questions`), chip(`${c.correct} correct`, 'g'), chip(`${c.wrong} wrong`, 'r'), chip(`${c.skipped} skipped`, 'a'));
  $('twarn').textContent = missingForTab ? 'The open tab’s test is not captured yet. Press Refresh on its page.' : '';
  renderSend();
}

$('fetchnow').onclick = async () => {
  const tab = await activeTab();
  say('msg', 'Asking the page…');
  try { await chrome.tabs.sendMessage(tab.id, { cmd: 'fetch-now' }); }
  catch { return say('msg', 'Open a pw.live test page and refresh it (F5) once.', 'bad'); }
  for (let i = 0; i < 10; i++) { await new Promise(r => setTimeout(r, 700)); await init(); if (mapped) break; }
  say('msg', mapped ? '' : 'Nothing arrived. Open the result page and try again.', 'warn');
};
$('view').onclick = async () => { await chrome.storage.local.set({ viewerData: mapped }); chrome.tabs.create({ url: chrome.runtime.getURL('viewer.html') }); };

// ---------------- details (collapsed by default) ----------------
const $n = id => $(id).value === '' ? NaN : Number($(id).value);
const readLog = () => ({ mapping_id: mapped.mappingId, exam: $('lgExam').value, type: $('lgType').value, paper: $('lgExam').value === 'advanced' ? $('lgPaper').value : null,
  date: $('lgDate').value, max: $n('lgMax'), physics: $n('lgPhy'), chemistry: $n('lgChem'), maths: $n('lgMath'), total: $n('lgPhy') + $n('lgChem') + $n('lgMath'), name: mapped.name ?? '' });
['lgExam', 'lgType', 'lgPaper', 'lgDate', 'lgPhy', 'lgChem', 'lgMath', 'lgMax'].forEach(id => $(id).addEventListener('input', renderSend));
$('editlog').onclick = () => { $('editbox').hidden = !$('editbox').hidden; $('editlog').textContent = $('editbox').hidden ? 'Edit details' : 'Hide details'; };
$('consent').onchange = async () => { await chrome.storage.local.set({ settings: { ...((await chrome.storage.local.get('settings')).settings ?? {}), consent: $('consent').checked } }); renderSend(); };

// ---------------- the one step ----------------
// Everything shown here comes from storage, so it stays right while the background worker sends, even if this popup was closed and reopened.
async function renderSend() {
  if (!mapped) return;
  if (_logFor !== mapped.mappingId) { // fill once per test so the student's edits are never overwritten
    _logFor = mapped.mappingId;
    const { overrides = {} } = await chrome.storage.local.get('overrides'); // the exam the student picked on the page banner
    const { log, warnings } = buildTestLog(mapped, overrides[mapped.mappingId] ?? {});
    $('lgExam').value = log.exam; $('lgType').value = log.type; $('lgPaper').value = log.paper ?? 'combined'; $('lgDate').value = log.date;
    $('lgPhy').value = log.physics; $('lgChem').value = log.chemistry; $('lgMath').value = log.maths; $('lgMax').value = log.max;
    _logWarn = warnings; $('editbox').hidden = true; $('editlog').textContent = 'Edit details'; say('smsg', '');
  }
  optima = buildOptimaPayload(mapped);
  const mid = mapped.mappingId, consent = $('consent').checked, n = optima.stats.n;
  const { logged = {}, jobs = {}, sendState = {}, session } = await chrome.storage.local.get(['logged', 'jobs', 'sendState', 'session']);
  const ss = sendState[mid], live = isLive(session), job = jobs[mid];
  const busy = ss && (ss.stage === 'adding' || ss.stage === 'analysing') && Date.now() - ss.t < 90000;
  const analysisErr = ss?.stage === 'done' && typeof ss.analysis === 'object';
  const sent = !!logged[mid] && (!consent || (!!job && job.status !== 'failed')) && !analysisErr && !(ss?.stage === 'error');

  $('paperrow').hidden = $('lgExam').value !== 'advanced';
  const l = readLog(); let problem = null;
  try { checkLog(l); } catch (e) { problem = e.message; }
  $('lgsum').textContent = [`${l.exam === 'advanced' ? 'JEE Advanced' : 'JEE Main'} · ${l.type === 'full' ? 'Full syllabus' : 'Partial'} · ${l.date || 'no date'}`,
    `Total ${Number.isFinite(l.total) ? l.total : '?'} / ${Number.isFinite(l.max) ? l.max : '?'} · P ${l.physics} · C ${l.chemistry} · M ${l.maths}`,
    ...(consent ? [n ? `The whole test goes to your error notebook (${optima.stats.wrong} wrong, ${optima.stats.skipped} skipped)` : 'No wrong or skipped questions: nothing to add to the notebook'] : []),
    ..._logWarn.map(w => '⚠ ' + w), ...(optima.stats.noEnglish && consent ? [`⚠ ${optima.stats.noEnglish} question(s) have no English image. Optima will refuse this test (your score is still saved).`] : []),
    ...(optima.stats.overLimit && consent ? [`⚠ Max ${MAX_QUESTIONS} questions per test`] : []), ...(optima.stats.tooBig && consent ? ['⚠ This test is too big to send (over 2 MB)'] : [])].join('\n');
  $('editlog').hidden = !!logged[mid]; if (logged[mid]) $('editbox').hidden = true;

  const btn = $('send');
  btn.textContent = busy ? (ss.stage === 'adding' ? 'Adding your score…' : 'Sending to your notebook…')
    : sent ? 'Sent ✓' : (analysisErr || ss?.stage === 'error') ? 'Try again' : logged[mid] && consent && (!job || job.status === 'failed') ? 'Analyse mistakes' : 'Send to JEETrack';
  btn.disabled = busy || sent || !live || (!logged[mid] && !!problem) || (consent && (optima.stats.overLimit || optima.stats.tooBig));
  $('jobstatus').hidden = !job;
  $('nb').hidden = !(job && job.status !== 'failed' && /^https:\/\//i.test(job.notebookUrl ?? ''));

  if (!live) say('smsg', 'Log in to JEETrack in this browser to continue.', 'warn');
  else if (busy) say('smsg', ss.stage === 'adding' ? 'Adding the score to your JEETrack tests…' : 'Score added ✓ Sending to your error notebook…');
  else if (ss?.stage === 'error') say('smsg', ss.message, 'bad');
  else if (ss?.stage === 'done' || sent) {
    const a = ss?.stage === 'done' ? ss.analysis : (job ? 'already' : 'off');
    if (a && typeof a === 'object') say('smsg', `Score saved ✓ but it could not be added to the error notebook: ${a.error}`, 'warn');
    else say('smsg', a === 'started' ? 'Added to JEETrack ✓ Sent to your error notebook. It is usually ready in under an hour.' : a === 'already' ? 'In your JEETrack tests ✓ Already in your error notebook.' : 'Added to your JEETrack tests ✓', 'ok');
  } else if (problem && !logged[mid]) say('smsg', problem, 'warn');
  else say('smsg', '');
}

$('send').onclick = async () => {
  if (!mapped) return;
  $('send').disabled = true; say('smsg', 'Starting…');
  const res = await chrome.runtime.sendMessage({ cmd: 'send', mappingId: mapped.mappingId, log: readLog() }).catch(e => ({ ok: false, error: e.message }));
  if (res && res.ok === false) say('smsg', res.error, 'bad'); // success/progress is rendered from storage
  renderSend();
};

$('jobstatus').onclick = async () => {
  const { jobs = {} } = await chrome.storage.local.get('jobs'), job = jobs[mapped?.mappingId];
  if (!job) return;
  try {
    const row = await fetchJobStatus(await getSettings(), job.jobId);
    job.status = row?.status === 'sent' ? 'received' : row?.status === 'done' ? 'ready' : (row?.status ?? job.status);
    if (row?.notebook_url) job.notebookUrl = row.notebook_url;
    await chrome.storage.local.set({ jobs });
    say('smsg', job.status === 'ready' ? 'Your error notebook is ready ✓' : job.status === 'failed' ? 'It did not reach Optima. Press Analyse mistakes to try again.' : 'Your notebook is still being built. It is usually ready in under an hour.', job.status === 'ready' ? 'ok' : job.status === 'failed' ? 'bad' : 'warn');
    renderSend();
  } catch (e) { say('smsg', e.message, 'bad'); }
};

$('nb').onclick = async () => {
  const { jobs = {} } = await chrome.storage.local.get('jobs'), u = jobs[mapped?.mappingId]?.notebookUrl;
  if (u && /^https:\/\//i.test(u)) chrome.tabs.create({ url: u });
};

// ---------------- start ----------------
chrome.storage.onChanged.addListener((c, area) => {
  if (area !== 'local') return;
  if (c.captures) init();
  if (c.session) refreshWho();
  if (c.session || c.sendState || c.logged || c.jobs) renderSend();
});
init(); // show the test straight away; the connection check runs alongside
autoConnect().then(async () => { await refreshWho(); await renderSend(); warmUp(await getSettings()); });
