// JEETrack x Optima: extension side.
// - buildOptimaPayload(): the mapped PW attempt (schema 2) as Optima's partner API wants it: the WHOLE test, unchanged, plus consent.
//   (Optima picks the wrong/skipped questions itself. The old "wrong + skipped, image URLs only" format is gone.)
// - getAccessToken / syncFromSite: the student's existing JEETrack login (access token only).
// - submitMock / fetchJobStatus: call JEETrack's edge functions. The extension never talks to Optima and holds no Optima key:
//   the key lives in the edge function secrets.

import { detectExam } from './detect.js';
export const MAX_QUESTIONS = 200;      // Optima: 1-200 questions per test
export const MAX_BYTES = 2_000_000;    // Optima: at most 2 MB per call

// JEETrack's own project. Both values are public by design (the web app ships them too).
export const DEFAULTS = { supabaseUrl: 'https://yskoeapemjuyyvkhlbpm.supabase.co', anonKey: 'sb_publishable_Rx1bw0gB3U_WGlw6I3hwqQ_SAAFkJeT' };

const letter = n => (Number.isInteger(n) && n >= 1 && n <= 26 ? String.fromCharCode(64 + n) : String(n));

// PW stores MCQ answers as 1-based option indexes (arrays) and numeric answers as strings.
export function answerText(v) {
  if (v == null || v === '') return '';
  if (Array.isArray(v)) return v.filter(x => x != null).map(letter).join(',');
  return String(v).trim();
}

// Prefer the English question image, otherwise the first one found.
export function pickQuestionImage(q) {
  const list = q?.images?.question ?? [];
  const en = list.find(i => i.lang === 'en');
  return (en ?? list[0])?.url ?? null;
}

// UTF-8 size without TextEncoder (Hindi question text is multi-byte; the 2 MB limit is in bytes).
const utf8Len = str => { let n = 0; for (let i = 0; i < str.length; i++) { const c = str.charCodeAt(i); n += c < 0x80 ? 1 : c < 0x800 ? 2 : (c >= 0xd800 && c < 0xdc00) ? (i++, 4) : 3; } return n; };

// mapped = output of mapPwAttempt(). payload.test is that object, unchanged. stats drive the popup's messages.
export function buildOptimaPayload(mapped) {
  const qs = mapped?.questions ?? [];
  const wrong = qs.filter(q => q.status === 'wrong').length, skipped = qs.filter(q => q.status === 'skipped').length;
  const noImage = qs.filter(q => (q.status === 'wrong' || q.status === 'skipped') && !pickQuestionImage(q)).length;
  // Optima (confirmed on staging) refuses the WHOLE test if any question, correct ones too, lacks an English question image.
  const noEnglish = qs.filter(q => !(q.images?.question ?? []).some(i => i.lang === 'en' && String(i.url).startsWith('https://static.pw.live/'))).length;
  const bytes = utf8Len(JSON.stringify(mapped ?? {}));
  return {
    payload: { consent: true, test: mapped },
    stats: { wrong, skipped, n: wrong + skipped, noImage, noEnglish, total: qs.length, bytes, overLimit: Math.max(0, qs.length - MAX_QUESTIONS), tooBig: bytes > MAX_BYTES - 20_000 },
  };
}

// ---------------- Supabase (JEETrack) ----------------
const base = s => String(s.supabaseUrl).replace(/\/+$/, '');
const hdr = (s, extra = {}) => ({ apikey: s.anonKey, 'Content-Type': 'application/json', ...extra });

async function saveSession(session) {
  // a refreshed token (same student) keeps the name we already resolved, so it never flickers
  const { session: prev } = await chrome.storage.local.get('session');
  if (prev && prev.uid && prev.uid === session.uid) { session.name ??= prev.name; session.nameDone ??= prev.nameDone; }
  await chrome.storage.local.set({ session }); return session;
}
export const jwtSub = t => { try { return JSON.parse(atob(String(t).split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).sub ?? null; } catch { return null; } };
export const isLive = s => !!s && Date.now() < s.expires_at;

const SITE_URLS = ['https://www.jeetrack.in/*', 'https://jeetrack.in/*'];
const authKey = settings => `sb-${new URL(settings.supabaseUrl).hostname.split('.')[0]}-auth-token`;

// Runs inside the JEETrack tab (must be self-contained): reads the student's existing login. Access token only.
function pageReadSession(key) {
  try {
    const s = JSON.parse(localStorage.getItem(key) || 'null');
    if (!s?.access_token) return null;
    let exp = s.expires_at ? s.expires_at * 1000 : 0;
    if (!exp) { try { exp = JSON.parse(atob(s.access_token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).exp * 1000; } catch { /* unknown */ } }
    return { access_token: s.access_token, expires_at: exp, email: s.user?.email ?? null, metaName: s.user?.user_metadata?.full_name ?? s.user?.user_metadata?.name ?? null };
  } catch { return null; }
}

// If a JEETrack tab is open and logged in, copy its session (works even if the tab was open before the extension loaded).
export async function syncFromSite(settings) {
  if (!chrome.tabs?.query || !chrome.scripting?.executeScript) return null;
  for (const tab of await chrome.tabs.query({ url: SITE_URLS })) {
    try {
      const [{ result } = {}] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: pageReadSession, args: [authKey(settings)] });
      if (result?.access_token && result.expires_at > Date.now() + 120_000)
        return saveSession({ access_token: result.access_token, refresh_token: null, expires_at: result.expires_at - 60_000, email: result.email, metaName: result.metaName, uid: jwtSub(result.access_token), source: 'site' });
    } catch { /* tab not scriptable; try the next */ }
  }
  return null;
}

export async function getAccessToken(settings) {
  const { session } = await chrome.storage.local.get('session');
  if (session && Date.now() < session.expires_at) return session.access_token;
  const fresh = await syncFromSite(settings).catch(() => null); // the open, logged-in JEETrack tab keeps its own token fresh
  if (fresh) return fresh.access_token;
  throw new Error(session ? 'Your JEETrack login timed out. Open JEETrack once, then try again.' : 'Not connected. Log in to JEETrack in this browser, then try again.');
}

// The first call after a pause pays a cold start. A free OPTIONS ping when the popup opens hides most of it.
export const warmUp = settings => Promise.resolve().then(() => fetch(`${base(settings)}/functions/v1/submit-mock`, { method: 'OPTIONS' })).catch(() => {});

// POST to the edge function with the user's JWT. Sends nothing anywhere else. payload = { consent, test, test_id }
export async function submitMock(settings, payload) {
  const jwt = await getAccessToken(settings);
  const r = await fetch(`${base(settings)}/functions/v1/submit-mock`, { method: 'POST', headers: hdr(settings, { Authorization: `Bearer ${jwt}` }), body: JSON.stringify(payload) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error ?? `submit-mock replied ${r.status}`);
  return j; // { job_id, status: received | ready, notebook_url, repeat }
}

// Asks JEETrack's optima-status function (which asks Optima, at most once a minute per job) and returns { status, notebook_url }.
// status: received | ready | failed.
export async function fetchJobStatus(settings, jobId) {
  const jwt = await getAccessToken(settings);
  const r = await fetch(`${base(settings)}/functions/v1/optima-status`, { method: 'POST', headers: hdr(settings, { Authorization: `Bearer ${jwt}` }), body: JSON.stringify({ job_ids: [jobId] }) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error ?? `status check failed (${r.status})`);
  const hit = (j.jobs ?? []).find(x => x.id === jobId);
  if (hit) return hit;
  // not in the "pending" list: it is already ready or failed, which the student can read from their own row (RLS)
  const rr = await fetch(`${base(settings)}/rest/v1/optima_jobs?id=eq.${encodeURIComponent(jobId)}&select=status,notebook_url`, { headers: hdr(settings, { Authorization: `Bearer ${jwt}` }) });
  if (!rr.ok) throw new Error(`status check failed (${rr.status})`);
  return (await rr.json())[0] ?? null;
}

// ---------------- Add the mock's scores to the student's JEETrack tests ----------------
const subjectKey = q => { const t = String(q.subject ?? '').toLowerCase(); return /phy/.test(t) ? 'physics' : /chem/.test(t) ? 'chemistry' : /math/.test(t) ? 'maths' : null; };
const localDate = s => { const d = s ? new Date(s) : new Date(); const x = isNaN(d) ? new Date() : d; return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`; };

// mapped = mapPwAttempt() output. Subject scores are summed from the questions, so subjects always add up to total (the app's own rule).
// override = { exam?, paper? } the student picked (on the page banner or in the popup).
export function buildTestLog(mapped, override = {}) {
  const sums = { physics: 0, chemistry: 0, maths: 0 }; let unknown = 0;
  for (const q of mapped?.questions ?? []) { const k = subjectKey(q); k ? (sums[k] += Number(q.score) || 0) : (unknown += q.score ? 1 : 0); }
  const total = sums.physics + sums.chemistry + sums.maths;
  const d = detectExam(mapped, override), warnings = [];
  if (unknown) warnings.push(`${unknown} scored question(s) have no Physics/Chemistry/Maths subject and are not counted.`);
  if (mapped?.score != null && Math.abs(Number(mapped.score) - total) > 0.01) warnings.push(`PW total is ${mapped.score} but the questions add up to ${total}. Check the numbers.`);
  if (mapped?.totalMarks == null) warnings.push(`PW did not give max marks; assumed ${d.max}.`);
  if (d.weak) warnings.push(`This looks like ${d.label} (${d.reasons.join(', ')}). Check the exam before sending.`);
  else if (d.paperGuessed) warnings.push('Paper 1 or Paper 2 could not be told. Check the paper.');
  return {
    log: { mapping_id: mapped?.mappingId ?? '', exam: d.exam, type: d.type, paper: d.paper, date: localDate(mapped?.endedAt), max: d.max,
      physics: sums.physics, chemistry: sums.chemistry, maths: sums.maths, total, name: mapped?.name ?? '' },
    warnings, detected: d,
  };
}

// One round trip: the log_pw_mock database function (runs as the student, so row-level security applies).
// Adds the test to the student's tests, remembers the PW attempt (no duplicates) and tells the app to refresh.
export async function logMock(settings, log) {
  const jwt = await getAccessToken(settings);
  const r = await fetch(`${base(settings)}/rest/v1/rpc/log_pw_mock`, { method: 'POST', headers: hdr(settings, { Authorization: `Bearer ${jwt}` }), body: JSON.stringify({ p: log }) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.message ?? `could not add the test (${r.status})`);
  return j; // { test_id, created }
}

// The same name the JEETrack app shows: user_preferences.username, else the Google name, else the part of the email before @.
// The email itself is never displayed anywhere in the extension.
export async function loadProfileName(settings) {
  const { session } = await chrome.storage.local.get('session');
  if (!isLive(session) || session.nameDone) return session ?? null;
  let username = '', ok = false;
  try {
    const uid = session.uid ?? jwtSub(session.access_token);
    const r = await fetch(`${base(settings)}/rest/v1/user_preferences?select=username&user_id=eq.${encodeURIComponent(uid)}&limit=1`, { headers: hdr(settings, { Authorization: `Bearer ${session.access_token}` }) });
    if (r.ok) { ok = true; username = String((await r.json())[0]?.username ?? '').trim(); }
  } catch { /* offline: fall back below, try again next time */ }
  const name = username || session.metaName || String(session.email ?? '').split('@')[0] || 'Student';
  const next = { ...session, uid: session.uid ?? jwtSub(session.access_token), name, nameDone: ok };
  await chrome.storage.local.set({ session: next });
  return next;
}
