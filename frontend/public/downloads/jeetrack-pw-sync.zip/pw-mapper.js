// PW (api.penpencil.co) -> JEETrack normalized attempt.
// qRes  = response of .../tests/mapping/{mappingId}/preview-test
// myRes = response of .../tests/{testId}/my-result (optional: rank/percentile/attempt title)
// Keeps metrics + PW ids only: no question/solution images, no topper data.
// Anything unexpected is reported in `warnings` instead of silently guessed.

const norm = s => String(s ?? '').toLowerCase().replace(/[^a-z]/g, '');
const OK = new Set(['correct', 'right']);
const BAD = new Set(['wrong', 'incorrect']);
const SKIP = new Set(['unattempted', 'notattempted', 'skipped', 'unanswered', 'notanswered', 'notvisited']);

function nameMap(sections = []) {
  const m = {};
  const put = x => { if (x?._id && x?.name) m[x._id] = x.name; };
  for (const s of sections)
    for (const sub of s.subjects ?? []) {
      put(sub.subjectId);
      for (const c of sub.chapters ?? []) {
        put(c.chapterId);
        for (const t of c.topics ?? []) {
          put(t.topicId);
          for (const st of t.subTopics ?? []) put(st.subTopicId);
        }
      }
    }
  return m;
}

const idOf = x => (x && typeof x === 'object' ? x._id : x);
const arr = x => (Array.isArray(x) ? x : x == null || x === '' ? [] : [x]);


// ---- image URL discovery -------------------------------------------------
// We don't know PW's exact field names, so walk the question object and collect anything that
// looks like an image URL: plain https strings ending in .png/.jpg/..., or {baseUrl, key} pairs.
const IMG_EXT = /\.(png|jpe?g|webp|gif|svg|avif)(?:[?#]|$)/i;
const LANG_KEYS = { en: 'en', english: 'en', hi: 'hi', hindi: 'hi' };
const langTag = s => { s = String(s).toLowerCase(); return s.startsWith('en') ? 'en' : s.startsWith('hi') ? 'hi' : s; };

function collectImages(node, path = [], lang = null, out = [], depth = 0) {
  if (node == null || depth > 8 || out.length > 40) return out;
  if (typeof node === 'string') {
    if (/^https?:\/\//i.test(node) && (IMG_EXT.test(node) || /image|img/i.test(path.join('.'))))
      out.push({ url: node, path: path.join('.'), lang });
    return out;
  }
  if (Array.isArray(node)) { node.forEach((v, i) => collectImages(v, [...path, i], lang, out, depth + 1)); return out; }
  if (typeof node === 'object') {
    let l = lang;
    for (const k of ['language', 'lang', 'languageCode']) if (typeof node[k] === 'string') l = langTag(node[k]);
    const pair = typeof node.baseUrl === 'string' && typeof node.key === 'string' && /^https?:\/\//i.test(node.baseUrl);
    if (pair) out.push({ url: node.baseUrl.replace(/\/+$/, '') + '/' + node.key.replace(/^\/+/, ''), path: path.join('.'), lang: l });
    for (const [k, v] of Object.entries(node)) {
      if (pair && (k === 'baseUrl' || k === 'key')) continue;
      collectImages(v, [...path, k], LANG_KEYS[k.toLowerCase()] ?? l, out, depth + 1);
    }
  }
  return out;
}

function groupImages(list) {
  const g = { question: [], solution: [], options: [] }, seen = new Set();
  for (const im of list) {
    const key = im.url + '|' + (im.lang ?? '');
    if (seen.has(key)) continue; seen.add(key);
    const o = im.path.match(/(?:^|\.)options\.(\d+)(?:\.|$)/i);
    if (o) g.options.push({ ...im, opt: +o[1] });
    else if (/solution|explanation|hint/i.test(im.path)) g.solution.push(im);
    else g.question.push(im);
  }
  return g;
}

export function mapPwAttempt(qRes, mappingId, myRes = null) {
  const d = qRes?.data;
  if (!Array.isArray(d?.questions) || !Array.isArray(d?.sections))
    throw new Error('preview-test response has unexpected shape (need data.questions[] and data.sections[])');
  const warnings = new Set();
  const names = nameMap(d.sections);
  const sectionName = Object.fromEntries(d.sections.map(s => [s.sectionId?._id, s.sectionId?.name]));
  const my = myRes?.data ?? null;
  const nameOf = id => (id && typeof id === 'object' ? id.name : names[id]) ?? null;

  const questions = d.questions.map(({ question: q, yourResult: y, averageResult: a }, i) => {
    q = q ?? {}; y = y ?? {};
    if (!y.status && !('yourResult' in (d.questions[i] ?? {}))) warnings.add('some questions have no yourResult');

    const numeric = /numeric|integer|decimal/i.test(q.type ?? '') || (!(q.options?.length) && q.solutionText != null);
    const optIndex = raw => {
      const id = idOf(raw);
      const k = (q.options ?? []).findIndex(o => o._id === id);
      return k < 0 ? null : k + 1; // 1-based, as shown on PW
    };

    const marked = numeric ? (y.markedSolutionText ?? arr(y.markedSolutions)[0] ?? null) || null : arr(y.markedSolutions).map(optIndex);
    const correct = numeric
      ? (q.solutionText ?? (q.solutions?.length ? arr(q.solutions).map(idOf).join(',') : null))
      : arr(q.solutions).map(optIndex);
    const empty = numeric ? marked == null : marked.length === 0;

    // status: trust PW's label when we recognise it, else derive from marks and warn
    const k = norm(y.status);
    let status;
    if (OK.has(k)) status = 'correct';
    else if (BAD.has(k)) status = 'wrong';
    else if (SKIP.has(k)) status = 'skipped';
    else {
      if (k) warnings.add(`unknown status "${y.status}" – derived from marks`);
      status = empty ? 'skipped' : (y.score ?? 0) > 0 ? 'correct' : 'wrong';
    }

    return {
      qno: q.questionNumber ?? i + 1,
      pwQuestionId: q._id,
      type: q.type,
      section: sectionName[q.sectionId] ?? null,
      subject: nameOf(q.subjectId),
      chapter: nameOf(q.chapterId),
      topic: nameOf(q.topicId) ?? nameOf(q.qbgTopicId),
      subTopic: nameOf(q.subTopicId),
      difficulty: q.difficultyLevel, // 1 = easy, 2 = medium
      optionCount: q.options?.length ?? 0,
      images: groupImages(collectImages(q)), // question / solution / option image URLs
      status,
      marked,
      correct,
      score: y.score ?? 0,
      positiveMarks: q.positiveMarks,
      negativeMarks: -Math.abs(q.negativeMarks ?? 0),
      timeSec: y.timeTaken ?? 0, // seconds (PW shows e.g. "3s")
      underReview: y.isUnderReview ?? false,
      allCorrectPct: a?.correctPercentile ?? null, // % of students who got it right
      avg: a ?? null, // PW's raw averageResult (kept: may hold per-option % etc.)
    };
  });

  const count = s => questions.filter(x => x.status === s).length;
  if (questions.length && questions.every(x => !x.images.question.length))
    warnings.add('no question image URLs found – see "Debug: field names" in the viewer, or send Raw (debug)');
  else if (questions.some(x => !x.images.question.length))
    warnings.add(`${questions.filter(x => !x.images.question.length).length} question(s) have no image URL`);
  if (!my) warnings.add('no my-result data: rank/percentile/total marks missing');
  return {
    schema: 2,
    source: 'pw',
    testId: d.test?._id,
    mappingId,
    name: d.test?.name,
    attemptTitle: my?.attemptFilter?.find?.(a => a.isSelected)?.title?.trim() ?? null,
    isLive: d.isLiveAttempt,
    endedAt: my?.testStudentMapping?.endedAt ?? null,
    rank: my?.rank ?? null,
    percentile: my?.percentile ?? null,
    isPredictive: my?.infoMessage?.isPredictive ?? null,
    score: my?.yourPerformance?.userScore ?? questions.reduce((n, x) => n + x.score, 0),
    totalMarks: my?.test?.totalMarks ?? null,
    counts: { correct: count('correct'), wrong: count('wrong'), skipped: count('skipped') },
    warnings: [...warnings],
    debug: { // field NAMES only (no content), to diagnose shape differences
      topKeys: Object.keys(d),
      questionKeys: Object.keys(d.questions[0]?.question ?? {}),
      yourResultKeys: Object.keys(d.questions[0]?.yourResult ?? {}),
      averageResultKeys: Object.keys(d.questions[0]?.averageResult ?? {}),
      imagePaths: questions.slice(0, 3).flatMap(x => [...x.images.question, ...x.images.solution].map(i => i.path)),
    },
    questions,
  };
}
