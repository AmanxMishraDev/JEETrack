import { jwtSub, loadProfileName, DEFAULTS } from './optima.js';
import { sendToJeeTrack } from './sender.js';
import { mapPwAttempt } from './pw-mapper.js';
import { detectExam } from './detect.js';
// Stores captured raw responses (keyed by testMappingId) and a small diagnostics log.
const MAX = 15;
let chain = Promise.resolve();

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.cmd === 'send') { // popup or on-page banner: add the score, then (if agreed) send the questions
    sendToJeeTrack(msg.mappingId, { log: msg.log }).then(r => sendResponse({ ok: true, ...r })).catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg?.cmd === 'view') { openViewer(msg.mappingId).then(() => sendResponse({ ok: true })).catch(e => sendResponse({ ok: false, error: e.message })); return true; }
  if (msg?.src === 'jt-site') { chain = chain.then(() => saveSiteSession(msg.session)).catch(e => console.error('[jt-site]', e)); return; }
  if (msg?.src !== 'jt-pw') return;
  chain = chain.then(() => (msg.kind === 'diag' ? logDiag(msg) : save(msg, sender))).catch(e => console.error('[jt-pw]', e));
});

async function logDiag({ event, detail }) {
  const { diag = [] } = await chrome.storage.local.get('diag');
  diag.push({ t: Date.now(), event, detail });
  await chrome.storage.local.set({ diag: diag.slice(-30) });
}

function parseIds(kind, url) {
  const u = new URL(url);
  if (kind === 'q') return { mappingId: u.pathname.match(/\/mapping\/([a-f0-9]+)\//)?.[1] ?? null, testId: null };
  return {
    testId: u.pathname.match(/\/tests\/([a-f0-9]+)\/my-result/)?.[1] ?? u.searchParams.get('testId'),
    mappingId: u.searchParams.get('testMappingId'),
  };
}

async function save({ kind, url, json }, sender) {
  if (!json?.data) return logDiag({ event: 'empty-response', detail: `${kind} ${url}` });
  const ids = parseIds(kind, url);
  const mappingId = ids.mappingId;
  if (!mappingId) return logDiag({ event: 'no-mapping-id', detail: url });

  const { captures = {} } = await chrome.storage.local.get('captures');
  const c = captures[mappingId] ?? { mappingId };
  c.t = Date.now();
  if (kind === 'q') { c.q = json; c.testId = json.data?.test?._id ?? c.testId; }
  else { c.my = json; c.testId = ids.testId ?? c.testId; }
  captures[mappingId] = c;

  const keys = Object.keys(captures).sort((a, b) => captures[b].t - captures[a].t);
  for (const k of keys.slice(MAX)) delete captures[k];
  // A small summary for the on-page banner (name, score, detected exam), so the banner never has to understand PW's format.
  const { summaries = {} } = await chrome.storage.local.get('summaries');
  try { if (c.q) summaries[mappingId] = summarize(c, mappingId); } catch { /* incomplete capture: the banner keeps showing "fetching" */ }
  for (const k of Object.keys(summaries)) if (!captures[k]) delete summaries[k];
  await chrome.storage.local.set({ captures, summaries });

  if (sender?.tab?.id != null) {
    const both = c.q && c.my;
    chrome.action.setBadgeBackgroundColor({ tabId: sender.tab.id, color: both ? '#1b7938' : '#eaaa2e' });
    chrome.action.setBadgeText({ tabId: sender.tab.id, text: both ? '2/2' : '1/2' });
  }
}

// Session copied from the JEETrack website tab (access token only). Logging out of JEETrack disconnects the extension too,
// but a manual sign-in done in the popup is never touched.
async function saveSiteSession(sess) {
  const { session } = await chrome.storage.local.get('session');
  if (!sess?.access_token) { if (session?.source === 'site') await chrome.storage.local.remove('session'); return; }
  if (session && session.source !== 'site' && Date.now() < session.expires_at) return;
  const uid = jwtSub(sess.access_token);
  const keep = session && session.uid === uid ? { name: session.name, nameDone: session.nameDone } : {};
  await chrome.storage.local.set({ session: { access_token: sess.access_token, refresh_token: null, expires_at: (sess.expires_at || Date.now() + 3300_000) - 60_000, email: sess.email ?? null, metaName: sess.metaName ?? null, uid, source: 'site', ...keep } });
  await loadProfileName({ ...DEFAULTS });
}

function summarize(c, mappingId) {
  const m = mapPwAttempt(c.q, mappingId, c.my ?? null), d = detectExam(m);
  return { name: m.name, score: m.score, max: m.totalMarks ?? d.max, n: m.questions.length, counts: m.counts, hasResult: !!c.my,
    exam: d.exam, paper: d.paper, label: d.label, weak: d.weak, t: Date.now() };
}

// "View" on the page banner: open the clean viewer for this test in a new tab.
async function openViewer(mappingId) {
  const { captures = {} } = await chrome.storage.local.get('captures'), c = captures[mappingId];
  if (!c?.q) throw new Error('This test is not captured yet.');
  await chrome.storage.local.set({ viewerData: mapPwAttempt(c.q, mappingId, c.my ?? null) });
  await chrome.tabs.create({ url: chrome.runtime.getURL('viewer.html') });
}
