// Runs inside the PW page (MAIN world).
// 1) Passively copies the JSON bodies of preview-test / my-result when the page loads them.
// 2) If a test page is open and one of them is missing, fetches it itself, replaying the
//    headers the page already used for api.penpencil.co. Those headers (incl. the auth token)
//    stay inside this closure: they are never stored, logged or sent anywhere except back to
//    api.penpencil.co for these two fixed GET URLs.
(() => {
  if (window.__jtHooked) return;
  window.__jtHooked = true;

  const API = 'https://api.penpencil.co';
  const HEX = '[a-f0-9]{24}';
  const RULES = [
    { kind: 'q',  re: new RegExp(`/tests/mapping/(${HEX})/preview-test`) },
    { kind: 'my', re: new RegExp(`/tests/(${HEX})/my-result`) },
  ];
  const isApi = url => { try { return new URL(url, location.href).hostname === 'api.penpencil.co'; } catch { return false; } };
  const kindOf = url => {
    try { const u = new URL(url, location.href); return isApi(u.href) ? (RULES.find(r => r.re.test(u.pathname))?.kind ?? null) : null; }
    catch { return null; }
  };
  const mappingOf = (kind, url) => {
    const u = new URL(url, location.href);
    return kind === 'q' ? u.pathname.match(RULES[0].re)?.[1] : u.searchParams.get('testMappingId');
  };

  const post = payload => window.postMessage({ src: 'jt-pw', ...payload }, location.origin);
  const diag = (event, detail = '') => post({ kind: 'diag', event, detail: String(detail).slice(0, 200) });
  const got = new Set(); // "q:<mappingId>" / "my:<mappingId>"
  const emit = (kind, url, json) => {
    const abs = new URL(url, location.href).href;
    const mid = mappingOf(kind, abs);
    if (mid && json?.data) got.add(`${kind}:${mid}`);
    post({ kind, url: abs, json });
  };

  // ---- remember the headers the page uses for the API (in memory only) ----
  let lastHeaders = null;
  const remember = h => { if (h && h.authorization) lastHeaders = h; };
  const toObj = h => {
    const o = {};
    try {
      if (!h) return o;
      if (typeof h.forEach === 'function' && !Array.isArray(h)) h.forEach((v, k) => (o[String(k).toLowerCase()] = v));
      else if (Array.isArray(h)) h.forEach(([k, v]) => (o[String(k).toLowerCase()] = v));
      else Object.entries(h).forEach(([k, v]) => (o[k.toLowerCase()] = v));
    } catch {}
    return o;
  };

  // ---- fetch hook ----
  const _fetch = window.fetch;
  window.fetch = async function (...args) {
    const res = await _fetch.apply(this, args);
    try {
      const req = args[0], url = typeof req === 'string' ? req : req?.url;
      if (isApi(url)) {
        remember({ ...toObj(typeof req === 'object' ? req.headers : null), ...toObj(args[1]?.headers) });
        const kind = kindOf(url);
        if (kind) res.clone().json().then(j => emit(kind, url, j)).catch(e => diag('parse-fail', e.message));
      }
    } catch {}
    return res;
  };

  // ---- XMLHttpRequest hook (axios) ----
  const X = XMLHttpRequest.prototype, _open = X.open, _set = X.setRequestHeader, _send = X.send;
  X.open = function (method, url, ...rest) {
    try {
      if (isApi(url)) {
        this.__jtUrl = url; this.__jtH = {};
        const kind = kindOf(url);
        if (kind) this.addEventListener('load', () => {
          try { emit(kind, url, this.responseType === 'json' ? this.response : JSON.parse(this.responseText)); }
          catch (e) { diag('parse-fail', e.message); }
        });
      }
    } catch {}
    return _open.call(this, method, url, ...rest);
  };
  X.setRequestHeader = function (k, v) { try { if (this.__jtH) this.__jtH[String(k).toLowerCase()] = v; } catch {} return _set.call(this, k, v); };
  X.send = function (...a) { try { if (this.__jtH) remember(this.__jtH); } catch {} return _send.apply(this, a); };

  // ---- active fetch of whatever is missing for the test page that is open ----
  const pageIds = () => {
    const u = new URL(location.href);
    const mappingId = u.searchParams.get('testMappingId') ?? u.searchParams.get('testMapId') ?? u.searchParams.get('mappingId');
    const testId = u.pathname.match(new RegExp(`/test/(${HEX})`))?.[1] ?? u.searchParams.get('testId');
    return { mappingId: mappingId && new RegExp(`^${HEX}$`).test(mappingId) ? mappingId : null, testId };
  };
  const tried = new Set();
  async function fetchMissing({ force = false } = {}) {
    const { mappingId, testId } = pageIds();
    if (!mappingId) return force && diag('no-ids', 'URL has no testMappingId/testMapId');
    if (!lastHeaders) return diag('no-auth-yet', 'page has not made an authenticated API call yet; wait a few seconds and retry');
    const jobs = [];
    if (!got.has(`q:${mappingId}`)) jobs.push(['q', `${API}/v3/test-service/tests/mapping/${mappingId}/preview-test`]);
    if (testId && !got.has(`my:${mappingId}`)) jobs.push(['my', `${API}/v3/test-service/tests/${testId}/my-result?testId=${testId}&testMappingId=${mappingId}`]);
    for (const [kind, url] of jobs) {
      const key = `${kind}:${mappingId}`;
      if (!force && tried.has(key)) continue;
      tried.add(key);
      try {
        const { ['content-length']: _l, host: _h, ...headers } = lastHeaders;
        const res = await _fetch(url, { method: 'GET', headers });
        if (!res.ok) { diag(`fetch-${kind}-http`, res.status); continue; }
        const json = await res.json();
        if (!json?.data) { diag(`fetch-${kind}-nodata`, JSON.stringify(json).slice(0, 120)); continue; }
        emit(kind, url, json); diag(`fetched-${kind}`, 'ok');
      } catch (e) { diag(`fetch-${kind}-error`, e.message); }
    }
  }

  window.addEventListener('message', e => {
    if (e.source === window && e.data?.src === 'jt-cmd' && e.data.cmd === 'fetch-now') fetchMissing({ force: true });
  });

  // run on load and on every SPA navigation, after the page had a chance to load the data itself
  let lastHref = '';
  setInterval(() => {
    if (location.href === lastHref) return;
    lastHref = location.href;
    if (/\/test\//.test(location.pathname)) setTimeout(() => fetchMissing(), 4000);
  }, 1500);
})();
