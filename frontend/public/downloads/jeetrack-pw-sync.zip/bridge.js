// Isolated world: page -> background relay, and popup -> page commands.
window.addEventListener('message', e => {
  if (e.source !== window || e.origin !== location.origin) return;
  const d = e.data;
  if (d?.src !== 'jt-pw') return;
  if (d.kind !== 'diag' && !d.json) return;
  chrome.runtime.sendMessage({ src: 'jt-pw', kind: d.kind, url: d.url, json: d.json, event: d.event, detail: d.detail }).catch(() => {});
});
chrome.runtime.onMessage.addListener((m, _s, reply) => {
  if (m?.cmd === 'fetch-now') { window.postMessage({ src: 'jt-cmd', cmd: 'fetch-now' }, location.origin); reply({ ok: true }); }
});
