// Runs on jeetrack.in. If the student is logged in to JEETrack in this browser, hand their short-lived
// access token to the extension, so they never sign in or paste anything.
// Only the access token goes across (about 1 hour). The refresh token is NOT copied: two clients refreshing
// the same session can make Supabase revoke it and log the student out of JEETrack.
const KEY = 'sb-yskoeapemjuyyvkhlbpm-auth-token';
let timer = null;

function read() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const s = JSON.parse(raw);
    if (!s?.access_token) return null;
    let exp = s.expires_at ? s.expires_at * 1000 : 0;
    if (!exp) { try { exp = JSON.parse(atob(s.access_token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).exp * 1000; } catch { /* unknown expiry */ } }
    return { access_token: s.access_token, expires_at: exp, email: s.user?.email ?? null, metaName: s.user?.user_metadata?.full_name ?? s.user?.user_metadata?.name ?? null };
  } catch { return null; }
}

function push() {
  try { chrome.runtime.sendMessage({ src: 'jt-site', kind: 'session', session: read() }); }
  catch { clearInterval(timer); } // extension was reloaded; this old script just stops
}

push();
timer = setInterval(push, 20000); // the app refreshes its own token about hourly; keep ours current
document.addEventListener('visibilitychange', () => { if (!document.hidden) push(); });
