// Which JEETrack section does a PW test belong to? Decided from the test's STRUCTURE first, the name only as a hint.
// (A real example: PW calls a JEE Advanced paper "Milestone:3 (Paper:2)": there is no word "advanced" anywhere.)
//
// Strong signals for JEE Advanced: multiple-correct questions, paragraph / matrix-match questions, "Advanced" or "JEE (A)" in the name.
// Medium: "Paper 1" / "Paper 2" in the name or section names, a paper-sized total (180 / 186 / 198), a combined total of about 360, non-Mains marking.
// JEE Mains has only single-correct and numerical questions, +4 / -1.

export const PAPER_LABEL = { p1: 'Paper 1', p2: 'Paper 2', combined: 'Combined' };
export const examLabel = (exam, paper) => exam === 'advanced' ? `JEE Advanced${paper ? ' · ' + PAPER_LABEL[paper] : ''}` : 'JEE Mains';

export function paperFromText(t) {
  const m = /paper\s*[:\-–_#]?\s*(1|2|ii|i)\b/i.exec(String(t ?? ''));
  return m ? (/^(1|i)$/i.test(m[1]) ? 'p1' : 'p2') : null;
}

const isNumeric = q => /numeric|integer|decimal/i.test(q?.type ?? '') || (q?.optionCount === 0);

// mapped = mapPwAttempt() output. override = { exam?, paper? } chosen by the student (wins over everything).
export function detectExam(mapped, override = {}) {
  const Q = mapped?.questions ?? [];
  const name = `${mapped?.name ?? ''} ${mapped?.attemptTitle ?? ''}`;
  const sections = Q.map(q => q.section ?? '').join(' ');
  const total = Number(mapped?.totalMarks) || null;
  const reasons = []; let adv = 0, strong = false;

  if (Q.some(q => !isNumeric(q) && ((Array.isArray(q.correct) && q.correct.length > 1) || /multi/i.test(q.type ?? '')))) { adv += 3; strong = true; reasons.push('has multiple-correct questions'); }
  if (Q.some(q => /paragraph|comprehension|passage|matrix|match/i.test(`${q.type ?? ''} ${q.section ?? ''}`))) { adv += 3; strong = true; reasons.push('has paragraph or matrix questions'); }
  if (/\badv(?:anced)?\b|\bjee[\s\-]*\(?a\)?(?![a-z])/i.test(name)) { adv += 3; strong = true; reasons.push('the name says Advanced'); }
  const nameMains = /\bmains?\b|\bjee[\s\-]*\(?m\)?(?![a-z])/i.test(name);
  const paperHint = paperFromText(name) ?? paperFromText(sections);
  if (paperHint) { adv += 2; reasons.push(`the name says ${PAPER_LABEL[paperHint]}`); }
  if (total && total > 150 && total <= 200 && Q.length <= 70) { adv += 1; reasons.push(`paper-sized total (${total})`); }
  else if (total && total >= 340 && total <= 380) { adv += 2; reasons.push(`combined total (${total})`); }
  const pos = new Set(Q.map(q => q.positiveMarks).filter(v => v > 0)), negTwo = Q.some(q => Math.abs(q.negativeMarks ?? 0) === 2);
  if ((pos.size && [...pos].some(v => v !== 4)) || negTwo) { adv += 1; reasons.push('Advanced-style marking'); }
  if (nameMains && !strong) adv = Math.min(adv, 2);

  let exam = adv >= 3 ? 'advanced' : 'mains';
  const weak = !strong && !override.exam && adv >= 3;
  if (override.exam === 'mains' || override.exam === 'advanced') { exam = override.exam; reasons.length = 0; reasons.push('chosen by you'); }

  const paper = exam === 'advanced' ? (override.paper ?? paperHint ?? ((total ?? 0) >= 300 ? 'combined' : 'p1')) : null;
  const type = exam === 'advanced' ? ((total ?? 0) >= 150 || Q.length >= 40 ? 'full' : 'partial') : ((total ?? 0) >= 270 || Q.length >= 75 ? 'full' : 'partial');
  const max = total ?? (exam === 'advanced' ? (paper === 'combined' ? 360 : 180) : 300);
  return { exam, paper, type, max, label: examLabel(exam, paper), reasons, weak, paperGuessed: exam === 'advanced' && !override.paper && !paperHint };
}
