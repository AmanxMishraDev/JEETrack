# JEETrack PW Sync (v0.4.0)

## Install (Chrome/Edge/Brave 111+)
1. Unzip. `chrome://extensions` → Developer mode → **Load unpacked** → this folder.
2. Open (or refresh with F5) any pw.live tab AFTER loading the extension.

## Use
1. Open any PW test **result** or **solutions** page (the URL must contain testMapId / testMappingId, as PW's does).
2. Wait ~5 s. The extension grabs what the page loads and fetches whatever is missing by itself.
   Badge `2/2` = questions + result captured.
3. Click the icon → check the summary → **Open viewer**: breakdowns, sanity checks and a **question-by-question review**
   (question image, your answer vs correct answer on the option buttons, solution image, time, marks). Click a number in the
   palette, use Prev/Next or the ← → keys; filter by subject/status.
   If images don't show, open **Debug: field names** at the bottom of the viewer and send me that text.
4. If the badge stays empty: click **Fetch now**. Still nothing → open **Diagnostics** in the popup.

| Diagnostic | Meaning |
|---|---|
| `no-auth-yet` | page hasn't made an API call yet; wait a few seconds, retry |
| `no-ids` | URL has no testMappingId/testMapId |
| `fetch-q-http 401/403` | PW rejected the replayed request (token expired: reload PW) |
| `fetch-q-nodata` | PW answered but with a different shape; use **Raw (debug)** |
| `parse-fail` | a captured response wasn't JSON |

## Privacy
The page's auth headers are held in memory inside the PW page only, and are replayed only to
api.penpencil.co for the two fixed GET URLs. They are never stored, logged or sent elsewhere.
Captured responses live in the extension's local storage (newest 15 tests).

## Tests (dev)
`npm i` then `npm test` (mapper variants + hook simulation with a fake PW API).
`node test/run.mjs q.json my.json` maps real saved responses offline.

## JEETrack PW Sync (v0.7.0)
1. **Log in to www.jeetrack.in in the same browser.** The extension picks the login up by itself (only the short-lived access token, never the refresh token). The student's name is shown as in the JEETrack app; the email is never displayed.
2. **Open your PW test page.** A tiny **"Fetching your test…"** pill appears at the top of the page. When the test data and the questions have both arrived, it expands into a card: **Test detected: <name> · score · questions · View**, a **Saves to** selector, the **Analyse mistakes** tick, and **Send to JEETrack**. No need to open the extension icon.
3. **Saves to** is where the test goes in JEETrack: JEE Mains, or JEE Advanced (Paper 1, Paper 2 or Combined). It is detected from the test's structure (multiple-correct or paragraph questions, "Paper 1/2", paper-sized totals), not just from the name. If it is only a guess, the selector is outlined in amber so you check it. Your choice always wins.
4. **View** opens a clean review page for the test (summary, subjects, weakest chapters, every question with your answer and the correct one).
5. **Send to JEETrack** adds the score to your JEETrack tests and, if *Analyse mistakes* is ticked, sends your wrong and skipped questions (image links, your answers, the correct answers) for analysis. Never name, email or account id. The same PW test is never added twice. The popup shows the same state and has *Edit details*.
Backend files and the app patch are in the zip (see supabase/SUPABASE_SETUP.md).
