// On-page helper for pw.live. As soon as a PW test page is open, a tiny "Fetching your test…" pill appears at the top.
// When the test data AND the questions have arrived, the pill expands into a card: "Send to JEETrack".
// No need to open the extension icon. Everything lives in a shadow root, so PW's styles can't touch it and it can't touch PW.
(() => {
  if (window.top !== window || window.__jtBanner) return;
  window.__jtBanner = true;

  const SITE = 'https://www.jeetrack.in/';
  const TIMING = window.__JT_TIMING ?? {}; // tests shorten the waits; unset in real use
  const RESULT_WAIT_MS = TIMING.resultWait ?? 8000;   // after the questions arrive, wait this long for the result numbers before expanding anyway
  const FETCH_FAIL_MS = TIMING.fetchFail ?? 14000;   // nothing captured for this long: say so (only on a page that clearly is a test)
  const DONE_HIDE_MS = 12000;
  const EXAMS = [['mains', 'JEE Mains'], ['advanced:p1', 'JEE Advanced · Paper 1'], ['advanced:p2', 'JEE Advanced · Paper 2'], ['advanced:combined', 'JEE Advanced · Combined']];
  const firstSeen = {}; let hiddenLocal = {}; let timer = null;

  // ---- fonts (must be declared on the page itself; shadow roots do not load @font-face) ----
  const u = p => chrome.runtime.getURL(p);
  if (!document.getElementById('jt-fonts')) {
    const st = document.createElement('style'); st.id = 'jt-fonts';
    st.textContent = `@font-face{font-family:'JT Syne';font-weight:800;src:url(${u('fonts/syne-latin-800-normal.woff2')}) format('woff2')}
@font-face{font-family:'JT DM Sans';font-weight:400;src:url(${u('fonts/dm-sans-latin-400-normal.woff2')}) format('woff2')}
@font-face{font-family:'JT DM Sans';font-weight:500;src:url(${u('fonts/dm-sans-latin-500-normal.woff2')}) format('woff2')}
@font-face{font-family:'JT DM Sans';font-weight:700;src:url(${u('fonts/dm-sans-latin-700-normal.woff2')}) format('woff2')}
@font-face{font-family:'JT Space Grotesk';font-weight:700;src:url(${u('fonts/space-grotesk-latin-700-normal.woff2')}) format('woff2')}`;
    (document.head || document.documentElement).append(st);
  }

  const host = document.createElement('div');
  host.id = 'jeetrack-pw-banner';
  host.style.cssText = 'all:initial;position:fixed;top:0;left:0;right:0;z-index:2147483647;pointer-events:none;';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `<style>
    :host{all:initial}
    *{box-sizing:border-box}
    [hidden]{display:none!important}
    .wrap{display:flex;justify-content:center;padding:12px 12px 0;pointer-events:none;font:14px/1.4 'JT DM Sans',system-ui,sans-serif;color:#f0eff5}
    /* ONE bar element. Pill and card are two sizes of it, so the pill really grows into the card. */
    .bar{pointer-events:auto;display:flex;align-items:center;gap:14px;flex-wrap:wrap;background:#111118;border:1px solid rgba(255,255,255,.12);box-shadow:0 12px 40px rgba(0,0,0,.55);overflow:hidden;
      width:var(--w);max-width:100%;padding:var(--p);border-radius:var(--r);
      transition:width .45s cubic-bezier(.2,.8,.2,1),padding .35s ease,border-radius .35s ease}
    .bar.pill{--w:236px;--p:6px 14px 6px 7px;--r:999px;flex-wrap:nowrap;gap:9px}
    .bar.pill.err{--w:318px}
    .bar.full{--w:840px;--p:10px 14px;--r:14px}
    .bar>*{animation:fade .4s ease both}
    @keyframes fade{from{opacity:0;transform:translateY(3px)}to{opacity:1;transform:none}}
    .wrap.enter .bar{animation:drop .3s ease-out}
    @keyframes drop{from{transform:translateY(-16px);opacity:0}to{transform:none;opacity:1}}
    @media (prefers-reduced-motion:reduce){.bar,.bar>*,.wrap.enter .bar{animation:none;transition:none}}
    img{width:32px;height:32px;border-radius:9px;display:block;flex:none}
    .pill img{width:26px;height:26px;border-radius:8px}
    .txt{flex:1;min-width:200px}
    .logo{font:800 15px/1 'JT Syne',system-ui,sans-serif;letter-spacing:-.04em;color:#f0eff5}
    .logo span{background:linear-gradient(135deg,#a695ff,#f472b6);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent}
    .line{margin-top:3px;color:#c9c8d6;font-size:13px}
    .line b{color:#f0eff5;font-weight:700}
    .small{font-size:12px;color:#9a99ad;margin-top:5px;display:flex;align-items:center;gap:6px;flex-wrap:wrap}
    .num{font-family:'JT Space Grotesk',system-ui,sans-serif;font-weight:700;color:#a695ff}
    .ok{color:#34d399}.bad{color:#f87171}.warn{color:#fbbf24}
    .ptxt{font-size:12.5px;color:#c9c8d6;white-space:nowrap;flex:1}
    .act{display:flex;align-items:center;gap:12px;margin-left:auto}
    label{display:flex;gap:6px;align-items:center;font-size:12px;color:#9a99ad;cursor:pointer;white-space:nowrap}
    input{accent-color:#7c6af7;margin:0;width:15px;height:15px;flex:none}
    select{font:500 12px 'JT DM Sans',system-ui,sans-serif;background:#1e1e28;color:#f0eff5;border:1px solid rgba(255,255,255,.14);border-radius:7px;padding:3px 6px;color-scheme:dark;max-width:190px}
    select.check{border-color:#fbbf24}
    button{font:700 13px 'JT DM Sans',system-ui,sans-serif;border:0;border-radius:9px;padding:9px 16px;cursor:pointer;color:#fff;background:linear-gradient(135deg,#7c6af7,#a67af5);white-space:nowrap}
    button:hover{filter:brightness(1.08)} button:disabled{opacity:.5;cursor:default}
    button.ghost{background:#1e1e28;border:1px solid rgba(255,255,255,.12);color:#f0eff5}
    button.link{background:none;border:0;padding:0;color:#a695ff;font:500 12px 'JT DM Sans',system-ui,sans-serif;text-decoration:underline;text-underline-offset:2px}
    button.mini{padding:4px 11px;font-size:12px;border-radius:99px}
    .x{background:none;border:0;color:#7a7990;font-size:20px;line-height:1;padding:4px 6px;font-weight:400}
    .x:hover{color:#f0eff5;filter:none}
    .spin{width:15px;height:15px;border-radius:50%;border:2px solid rgba(166,149,255,.25);border-top-color:#a695ff;animation:sp .8s linear infinite;flex:none}
    @keyframes sp{to{transform:rotate(360deg)}}
  </style><div class="wrap" id="wrap" hidden role="status" aria-live="polite"><div class="bar pill" id="bar"></div></div>`;
  const wrap = root.getElementById('wrap'), bar = root.getElementById('bar');

  // ---- helpers ----
  const el = (tag, props = {}, ...kids) => { const e = document.createElement(tag); Object.assign(e, props); e.append(...kids); return e; };
  const span = (text, cls) => el('span', { className: cls ?? '', textContent: text });
  const midFromUrl = () => { const q = new URLSearchParams(location.search); return q.get('testMappingId') ?? q.get('testMapId'); };
  const looksLikeTestPage = () => !!midFromUrl() || /test|result|solution|analysis/i.test(location.pathname);
  const isLive = s => !!s && Date.now() < s.expires_at;

  function pickMid(captures) {
    const fromUrl = midFromUrl();
    if (fromUrl) return fromUrl;
    if (!looksLikeTestPage()) return null; // never pop up on unrelated PW pages
    return Object.keys(captures).filter(id => captures[id].q && Date.now() - captures[id].t < 180000).sort((a, b) => captures[b].t - captures[a].t)[0] ?? null;
  }

  // name / score / questions / detected exam: prefer the background's summary, fall back to the raw capture
  function summaryOf(cap, sum) {
    if (sum) return sum;
    const q = cap.q?.data, my = cap.my?.data;
    return { name: q?.test?.name ?? 'Your test', n: q?.questions?.length ?? 0, score: my?.yourPerformance?.userScore ?? null, max: my?.test?.totalMarks ?? null, exam: 'mains', paper: null, label: 'JEE Mains', weak: false };
  }

  const send = async mid => { try { await chrome.runtime.sendMessage({ cmd: 'send', mappingId: mid }); } catch { /* the result arrives through storage */ } };
  const view = mid => { chrome.runtime.sendMessage({ cmd: 'view', mappingId: mid }).catch(() => {}); };
  const dismiss = async mid => { hiddenLocal[mid] = true; seq++; wrap.hidden = true; const { dismissed = {} } = await chrome.storage.local.get('dismissed'); dismissed[mid] = true; await chrome.storage.local.set({ dismissed }); render(); };
  const retry = key => { firstSeen[key] = Date.now(); window.postMessage({ src: 'jt-cmd', cmd: 'fetch-now' }, location.origin); render(); };

  const logo = () => el('img', { src: u('icons/icon-48.png'), alt: '' });
  const head = line => el('div', { className: 'txt' }, el('div', { className: 'logo' }, 'JEE', span('Track')), line);
  const closeBtn = mid => { const x = el('button', { className: 'x', title: 'Close', textContent: '×' }); x.onclick = () => dismiss(mid); return x; };

  const pill = (text, extra = []) => ({ mode: 'pill', err: extra.length > 0, kids: [logo(), ...(extra.length ? [] : [el('div', { className: 'spin' })]), el('div', { className: 'ptxt' }, text), ...extra] });
  const full = (mid, ...parts) => ({ mode: 'full', kids: [logo(), ...parts, closeBtn(mid)] });

  async function setOverride(mid, value) {
    const [exam, paper] = value.split(':'); const { overrides = {} } = await chrome.storage.local.get('overrides');
    overrides[mid] = exam === 'advanced' ? { exam, paper } : { exam }; await chrome.storage.local.set({ overrides });
  }

  let seq = 0, lastSig = '', lastMode = '';
  async function render() {
    clearTimeout(timer);
    const my = ++seq;
    const st = await chrome.storage.local.get(['captures', 'summaries', 'sendState', 'logged', 'jobs', 'session', 'settings', 'dismissed', 'overrides']);
    if (my !== seq) return; // a newer render (or a dismiss) already took over
    const captures = st.captures ?? {}, mid = pickMid(captures), cap = mid && captures[mid], key = mid ?? '__page';
    if (!mid && !looksLikeTestPage()) { wrap.hidden = true; lastSig = ''; return; }
    if (mid && (st.dismissed?.[mid] || hiddenLocal[mid])) { wrap.hidden = true; lastSig = ''; return; }
    firstSeen[key] ??= Date.now();
    const now = Date.now(), waited = now - firstSeen[key], consent = !!st.settings?.consent, ss = mid && st.sendState?.[mid];
    const again = ms => { timer = setTimeout(render, Math.max(120, ms)); };
    let view_; // { mode, kids, err? }

    if (ss && (ss.stage === 'adding' || ss.stage === 'analysing') && now - ss.t < 90000) {
      view_ = full(mid, el('div', { className: 'spin' }), head(el('div', { className: 'line' }, ss.stage === 'adding' ? 'Adding your score to JEETrack…' : 'Score added ✓ Sending to your Optima error notebook…')));
    } else if (ss?.stage === 'done' && (now - ss.t < DONE_HIDE_MS || typeof ss.analysis === 'object')) {
      const a = ss.analysis, bits = [span('✓ Added to JEETrack', 'ok'), span(ss.where ? ` · ${ss.where}` : '')];
      if (a === 'started') bits.push(span(' · Sent to your error notebook (usually ready in under an hour)'));
      else if (a === 'already') bits.push(span(' · Already in your error notebook'));
      else if (a && typeof a === 'object') bits.push(span(` · Error notebook: ${a.error}`, 'warn'));
      let act;
      if (a && typeof a === 'object') { act = el('button', { textContent: 'Try again' }); act.onclick = () => { act.disabled = true; send(mid); }; }
      else if (ss.notebookUrl && /^https:\/\//i.test(ss.notebookUrl)) { act = el('button', { className: 'ghost', textContent: 'Open my error notebook →' }); act.onclick = () => window.open(ss.notebookUrl, '_blank', 'noopener'); }
      else { act = el('button', { className: 'ghost', textContent: 'Open JEETrack' }); act.onclick = () => window.open(SITE, '_blank', 'noopener'); }
      view_ = full(mid, head(el('div', { className: 'line' }, ...bits)), act);
      if (typeof a !== 'object') again(DONE_HIDE_MS - (now - ss.t) + 50);
    } else if (ss?.stage === 'error' && now - ss.t < 10 * 60000) {
      const r = el('button', { textContent: 'Try again' }); r.onclick = () => send(mid);
      view_ = full(mid, head(el('div', { className: 'line' }, span('Could not send: ', 'bad'), span(ss.message ?? 'something went wrong'))), r);
    } else if (mid && st.logged?.[mid] && (!consent || (st.jobs?.[mid] && st.jobs[mid].status !== 'failed'))) {
      wrap.hidden = true; lastSig = ''; return; // already sent: stay out of the way
    } else if (!cap?.q) {
      // nothing captured yet: tiny "fetching" pill; if it never arrives, say so (only on a page that clearly is a test)
      if (waited < FETCH_FAIL_MS) { view_ = pill('Fetching your test…'); again(FETCH_FAIL_MS - waited + 50); }
      else if (midFromUrl()) { const r = el('button', { className: 'mini', textContent: 'Retry' }); r.onclick = () => retry(key); view_ = pill('Couldn’t read this test', [r]); }
      else { wrap.hidden = true; lastSig = ''; return; }
    } else if (!cap.my && waited < RESULT_WAIT_MS) {
      view_ = pill('Fetching your test…'); again(RESULT_WAIT_MS - waited + 50); // questions are in; waiting a moment for the result numbers
    } else if (!isLive(st.session)) {
      const open = el('button', { textContent: 'Open JEETrack' }); open.onclick = () => window.open(SITE, '_blank', 'noopener');
      view_ = full(mid, head(el('div', { className: 'line' }, 'Log in to JEETrack in this browser to send ', el('b', {}, summaryOf(cap, st.summaries?.[mid]).name), '.')), open);
    } else {
      // both the test data and the questions are here: the pill expands into the card
      const s = summaryOf(cap, st.summaries?.[mid]), ov = st.overrides?.[mid];
      const cur = ov ? (ov.exam === 'advanced' ? `advanced:${ov.paper ?? 'combined'}` : 'mains') : (s.exam === 'advanced' ? `advanced:${s.paper ?? 'combined'}` : 'mains');
      const sel = el('select', { title: s.weak && !ov ? 'Please check that this is the right exam' : 'Where this test is saved in JEETrack', className: s.weak && !ov ? 'check' : '' },
        ...EXAMS.map(([v, l]) => el('option', { value: v, textContent: l, selected: v === cur })));
      sel.onchange = () => setOverride(mid, sel.value);
      const seeBtn = el('button', { className: 'link', textContent: 'View' }); seeBtn.onclick = () => view(mid);
      const scoreTxt = s.score != null ? [span(String(s.score), 'num'), span(s.max ? ` / ${s.max}` : '')] : [];
      const cb = el('input', { type: 'checkbox', checked: consent });
      cb.onchange = async () => { const { settings = {} } = await chrome.storage.local.get('settings'); await chrome.storage.local.set({ settings: { ...settings, consent: cb.checked } }); };
      const lab = el('label', { title: 'Also send this test (its questions and my answers) to Optima to build my error notebook. Never my name or email.' }, cb, 'Analyse mistakes');
      const go = el('button', { textContent: 'Send to JEETrack' }); go.onclick = () => { go.disabled = true; send(mid); };
      view_ = full(mid,
        head(el('div', { className: 'line' }, 'Test detected: ', el('b', {}, s.name), ' · ', ...scoreTxt, s.n ? ` · ${s.n} questions` : '', ' · ', seeBtn)),
        el('div', { className: 'act' }, lab, go));
      view_.kids[1].append(el('div', { className: 'small' }, 'Saves to', sel)); // second line under the test: where it goes
    }

    // Same content as what is already on screen? Leave the DOM alone, so a click is never lost to a rebuilt button.
    const sig = [key, view_.mode, !!view_.err, view_.kids.map(k => k.textContent).join('|'), view_.kids.flatMap(k => [...k.querySelectorAll?.('select,input') ?? []]).map(i => i.value + i.checked).join(',')].join('#');
    if (sig !== lastSig || wrap.hidden) {
      lastSig = sig;
      const wasHidden = wrap.hidden;
      bar.className = `bar ${view_.mode}${view_.err ? ' err' : ''}`;
      bar.replaceChildren(...view_.kids);
      if (wasHidden) { wrap.classList.remove('enter'); void wrap.offsetWidth; wrap.classList.add('enter'); }
    }
    wrap.hidden = false; lastMode = view_.mode; void lastMode;
  }

  let pending = null;
  const soon = () => { clearTimeout(pending); pending = setTimeout(render, 60); };
  chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && (c.captures || c.summaries || c.sendState || c.logged || c.jobs || c.session || c.settings || c.dismissed || c.overrides)) soon(); });
  let lastUrl = location.href;
  setInterval(() => { if (location.href !== lastUrl) { lastUrl = location.href; hiddenLocal = {}; for (const k of Object.keys(firstSeen)) delete firstSeen[k]; render(); } }, 1200); // PW is a single-page app
  (document.body ? Promise.resolve() : new Promise(r => addEventListener('DOMContentLoaded', r, { once: true }))).then(() => { document.documentElement.append(host); render(); });
})();
