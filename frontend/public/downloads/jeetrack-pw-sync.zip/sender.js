// The one-step send: add the score to the student's JEETrack tests AND, if they agreed, send the test to Optima for the error notebook.
// Runs in the background worker, so it finishes even if the popup closes or the PW page navigates.
// Progress is written to storage (sendState) so the popup and the on-page banner both show it live.
import { mapPwAttempt } from './pw-mapper.js';
import { buildOptimaPayload, buildTestLog, logMock, submitMock, DEFAULTS, MAX_QUESTIONS } from './optima.js';
import { examLabel } from './detect.js';

const get = k => chrome.storage.local.get(k);
const settingsOf = async () => ({ ...DEFAULTS, ...((await get('settings')).settings ?? {}) });
const WITH_OPTIMA = new Set(['received', 'ready']); // a job in one of these states is already with Optima: never send it twice

async function setState(mid, st) {
  const { sendState = {} } = await get('sendState');
  sendState[mid] = { ...st, t: Date.now() };
  await chrome.storage.local.set({ sendState });
}

// Same rules the database enforces, so the student gets a clear message before anything is sent.
export function checkLog(l) {
  const nums = [l.max, l.physics, l.chemistry, l.maths].every(Number.isFinite);
  if (!l.date) throw new Error('Pick a date.');
  if (!nums) throw new Error('Fill all scores and max marks.');
  if (l.total > l.max) throw new Error(`Total ${l.total} is more than max ${l.max}.`);
}

export async function sendToJeeTrack(mid, { log } = {}) {
  try {
    const { captures = {}, jobs = {}, overrides = {} } = await get(['captures', 'jobs', 'overrides']);
    const cap = captures[mid];
    if (!cap?.q) throw new Error('This test is not captured yet. Open its PW result page.');
    const mapped = mapPwAttempt(cap.q, mid, cap.my ?? null);
    const L = log ?? buildTestLog(mapped, overrides[mid] ?? {}).log;
    checkLog(L);
    const settings = await settingsOf();

    // 1. the score goes into the student's tests (one database call; safe to repeat: no duplicates)
    await setState(mid, { stage: 'adding' });
    let r = await logMock(settings, L), testId = r.test_id;
    const saveLogged = async id => { const { logged = {} } = await get('logged'); logged[mid] = id; await chrome.storage.local.set({ logged }); };
    await saveLogged(testId);
    const out = { testId, created: r.created, analysis: 'off', where: examLabel(L.exam, L.paper) };

    // 2. the test goes to Optima (it builds the error notebook from the wrong and skipped questions), only if the student agreed.
    //    Independent of step 1: whatever happens here, the score is already saved.
    if (settings.consent) {
      const { payload, stats } = buildOptimaPayload(mapped), prev = jobs[mid];
      if (!stats.n) out.analysis = 'nothing';
      else if (stats.overLimit) out.analysis = { error: `Max ${MAX_QUESTIONS} questions per test.` };
      else if (stats.tooBig) out.analysis = { error: 'This test is too big to send (over 2 MB).' };
      else if (prev && WITH_OPTIMA.has(prev.status)) { out.analysis = 'already'; out.notebookUrl = prev.notebookUrl ?? null; }
      else {
        await setState(mid, { stage: 'analysing', testId });
        try {
          let res;
          try { res = await submitMock(settings, { ...payload, test_id: testId }); }
          catch (e) { // the student deleted the test in the app: add it again and retry once
            if (!/does not belong/.test(e.message)) throw e;
            testId = (await logMock(settings, L)).test_id; await saveLogged(testId); out.testId = testId;
            res = await submitMock(settings, { ...payload, test_id: testId });
          }
          const { jobs: j2 = {} } = await get('jobs');
          j2[mid] = { jobId: res.job_id, status: res.status ?? 'received', notebookUrl: res.notebook_url ?? null, t: Date.now() };
          await chrome.storage.local.set({ jobs: j2 });
          out.analysis = res.repeat ? 'already' : 'started'; out.notebookUrl = res.notebook_url ?? null;
        } catch (e) { out.analysis = { error: e.message }; } // the score is already saved; only the notebook step failed
      }
    }
    await setState(mid, { stage: 'done', ...out });
    return out;
  } catch (e) {
    await setState(mid, { stage: 'error', message: e.message });
    throw e;
  }
}
