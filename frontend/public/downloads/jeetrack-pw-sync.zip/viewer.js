// The clean review page for one captured PW test: summary first, then every question as a collapsible row.
(() => {
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const safe = u => /^https?:\/\//i.test(u);
  const num = v => Number.isFinite(+v) ? +v : 0;
  const fmtTime = s => { s = Math.round(num(s)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60; return h ? `${h}h ${m}m` : m ? `${m}m ${String(r).padStart(2, '0')}s` : `${r}s`; };
  const fmtMarked = m => Array.isArray(m) ? (m.length ? m.map(x => x ?? '?').join(', ') : '') : (m == null ? '' : String(m));
  const SUBJ_COLOR = s => /phy/i.test(s) ? 'var(--bl)' : /chem/i.test(s) ? 'var(--gn)' : /math/i.test(s) ? 'var(--am)' : 'var(--ac2)';
  const STATUS_LABEL = { correct: 'Correct', wrong: 'Wrong', skipped: 'Skipped' };

  let A = null, lang = '', fStatus = '', fSubject = '';
  const open = new Set();

  function load(a) {
    A = a;
    document.title = `${a.name ?? 'Test'} · JEETrack`;
    $('empty').hidden = true; $('main').hidden = false;
    $('tname').textContent = a.name ?? 'Your test';
    const d = a.endedAt ? new Date(a.endedAt) : null;
    $('tmeta').textContent = [d && !isNaN(d) ? d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : null, a.attemptTitle, `${a.questions.length} questions`].filter(Boolean).join(' · ');
    const langs = [...new Set(a.questions.flatMap(q => ['question', 'solution'].flatMap(k => (q.images?.[k] ?? []).map(i => i.lang)).filter(Boolean)))];
    lang = langs.find(l => /^en/i.test(l)) ?? langs[0] ?? '';
    drawHero(); drawSubjects(); drawChapters(); drawFilters(langs); drawList();
  }

  function drawHero() {
    const c = A.counts, attempted = c.correct + c.wrong, acc = attempted ? Math.round(100 * c.correct / attempted) : null;
    const time = A.questions.reduce((n, q) => n + num(q.timeSec), 0);
    const stat = (k, v) => `<div class="stat"><div class="k">${esc(k)}</div><div class="v">${esc(v)}</div></div>`;
    $('hero').innerHTML =
      `<div class="score">${esc(A.score ?? '–')}${A.totalMarks ? `<small>/ ${esc(A.totalMarks)}</small>` : ''}</div>` +
      `<div class="stats">${acc != null ? stat('Accuracy', acc + '%') : ''}${stat('Attempted', `${attempted}/${A.questions.length}`)}${time ? stat('Time', fmtTime(time)) : ''}` +
      `${A.rank ? stat('Rank', '#' + A.rank) : ''}${A.percentile != null ? stat('Percentile', (+A.percentile).toFixed(1)) : ''}</div>` +
      `<div class="pills"><span class="pill g">${c.correct} correct</span><span class="pill r">${c.wrong} wrong</span><span class="pill a">${c.skipped} skipped</span></div>`;
  }

  function drawSubjects() {
    const by = new Map();
    for (const q of A.questions) { const k = q.subject ?? 'Other'; const s = by.get(k) ?? { correct: 0, wrong: 0, skipped: 0, score: 0 }; s[q.status]++; s.score += num(q.score); by.set(k, s); }
    $('subjects').innerHTML = [...by].map(([name, s]) => {
      const n = s.correct + s.wrong + s.skipped || 1;
      return `<div class="card sub-card"><div class="nm"><i class="dot" style="background:${SUBJ_COLOR(name)}"></i>${esc(name)}</div>` +
        `<div class="sc" style="color:${SUBJ_COLOR(name)}">${esc(s.score)}</div><div class="ln">${s.correct} correct · ${s.wrong} wrong · ${s.skipped} skipped</div>` +
        `<div class="bar"><i class="c" style="width:${100 * s.correct / n}%"></i><i class="w" style="width:${100 * s.wrong / n}%"></i><i class="s" style="width:${100 * s.skipped / n}%"></i></div></div>`;
    }).join('');
  }

  function drawChapters() {
    const by = new Map();
    for (const q of A.questions) if (q.status !== 'correct' && q.chapter) { const k = q.chapter; const e = by.get(k) ?? { n: 0, subject: q.subject }; e.n++; by.set(k, e); }
    const top = [...by].sort((a, b) => b[1].n - a[1].n).slice(0, 6), max = top[0]?.[1].n || 1;
    $('chapWrap').hidden = !top.length;
    $('chapters').innerHTML = top.map(([name, e]) => `<div class="chap-row"><div class="nm">${esc(name)}<small>${esc(e.subject ?? '')}</small></div><div class="tr"><i style="width:${100 * e.n / max}%"></i></div><div class="n">${e.n}</div></div>`).join('');
  }

  function drawFilters(langs) {
    const c = A.counts, all = A.questions.length;
    const chip = (group, val, label, n, on) => `<button class="chip" data-g="${group}" data-v="${esc(val)}" aria-pressed="${on}">${esc(label)}${n != null ? `<b>${n}</b>` : ''}</button>`;
    $('fStatus').innerHTML = chip('status', '', 'All', all, !fStatus) + ['wrong', 'skipped', 'correct'].map(s => chip('status', s, STATUS_LABEL[s], c[s], fStatus === s)).join('');
    const subs = [...new Set(A.questions.map(q => q.subject).filter(Boolean))];
    $('fSubject').hidden = subs.length < 2;
    $('fSubject').innerHTML = chip('subject', '', 'All subjects', null, !fSubject) + subs.map(s => chip('subject', s, s, null, fSubject === s)).join('');
    $('fLang').hidden = langs.length < 2;
    $('fLang').innerHTML = langs.map(l => chip('lang', l, l.toUpperCase(), null, lang === l)).join('');
  }

  const imgs = list => list.filter(i => safe(i.url) && (!lang || !i.lang || i.lang === lang))
    .map(i => `<a href="${esc(i.url)}" target="_blank" rel="noopener noreferrer"><img class="qimg" data-src="${esc(i.url)}" alt="" referrerpolicy="no-referrer"></a>`).join('');

  function body(q) {
    const numeric = !q.optionCount, mk = new Set(Array.isArray(q.marked) ? q.marked : []), cr = new Set(Array.isArray(q.correct) ? q.correct : []);
    let opts = '';
    if (!numeric) for (let n = 1; n <= q.optionCount; n++) {
      const m = mk.has(n), c = cr.has(n), cls = m && c ? 'good' : m ? 'miss' : c ? 'ans' : '', tag = m && c ? 'your answer ✓' : m ? 'your answer ✗' : c ? 'correct answer' : '';
      opts += `<div class="opt ${cls}">${n}<small>${tag}</small>${imgs((q.images?.options ?? []).filter(o => o.opt === n - 1))}</div>`;
    }
    const mine = fmtMarked(q.marked), diff = q.difficulty === 1 ? 'Easy' : q.difficulty === 2 ? 'Medium' : q.difficulty === 3 ? 'Hard' : null;
    const facts = [q.topic && `Topic <b>${esc(q.topic)}</b>`, diff && `Difficulty <b>${diff}</b>`, q.allCorrectPct != null && `<b>${(+q.allCorrectPct).toFixed(0)}%</b> of students got it right`, q.type && `<b>${esc(q.type)}</b>`].filter(Boolean);
    const qi = imgs(q.images?.question ?? []), si = imgs(q.images?.solution ?? []);
    return (facts.length ? `<div class="facts">${facts.map(f => `<span>${f}</span>`).join('')}</div>` : '') +
      (qi || '<div class="imgfail">No question image was found for this question.</div>') +
      (numeric ? '' : `<div class="opts">${opts}</div>`) +
      `<div class="answer">You marked <b class="${q.status}">${mine ? esc(mine) : 'nothing (skipped)'}</b> · Correct <b class="correct">${esc(fmtMarked(q.correct) || '—')}</b></div>` +
      (si ? `<details><summary>Solution</summary>${si}</details>` : '');
  }

  function drawList() {
    const rows = A.questions.filter(q => (!fStatus || q.status === fStatus) && (!fSubject || q.subject === fSubject));
    $('list').innerHTML = rows.length ? rows.map(q => {
      const isOpen = open.has(q.qno), sign = num(q.score) > 0 ? '+' : '';
      return `<article class="q${isOpen ? ' open' : ''}" data-q="${q.qno}">` +
        `<button class="qh" aria-expanded="${isOpen}"><span class="qn">${q.qno}</span>` +
        `<span class="qt"><span class="l1"><i class="d" style="background:${SUBJ_COLOR(q.subject ?? '')}"></i>${esc(q.chapter ?? q.subject ?? 'Question')}</span><span class="l2">${esc(q.subject ?? '')}</span></span>` +
        `<span class="qr"><span class="t">${num(q.timeSec) ? fmtTime(q.timeSec) : ''}</span><span class="st ${q.status}">${STATUS_LABEL[q.status] ?? esc(q.status)}</span><span class="mk">${sign}${esc(num(q.score))}</span><span class="chev">›</span></span></button>` +
        `<div class="qb" ${isOpen ? '' : 'hidden'}>${isOpen ? body(q) : ''}</div></article>`;
    }).join('') : '<div class="none">No questions match these filters.</div>';
    loadImages();
  }

  // Images are fetched only for rows that are open (a 75-question test would otherwise load 75+ images at once).
  // The solution picture waits until its section is opened (a browser fetches even hidden images).
  function loadImages() { document.querySelectorAll('#list img[data-src]').forEach(i => { if (i.closest('details:not([open])')) return; i.src = i.dataset.src; i.removeAttribute('data-src'); }); }
  document.addEventListener('toggle', loadImages, true);

  document.addEventListener('click', e => {
    const chip = e.target.closest('button.chip[data-g]');
    if (chip && A) {
      const { g, v } = chip.dataset;
      if (g === 'status') fStatus = v; else if (g === 'subject') fSubject = v; else { lang = v; }
      drawFilters([...new Set(A.questions.flatMap(q => ['question', 'solution'].flatMap(k => (q.images?.[k] ?? []).map(i => i.lang)).filter(Boolean)))]); drawList(); return;
    }
    const head = e.target.closest('.qh');
    if (head && A) {
      const art = head.closest('.q'), n = +art.dataset.q, q = A.questions.find(x => x.qno === n), willOpen = !open.has(n);
      willOpen ? open.add(n) : open.delete(n);
      art.classList.toggle('open', willOpen); head.setAttribute('aria-expanded', willOpen);
      const b = art.querySelector('.qb'); b.hidden = !willOpen; b.innerHTML = willOpen ? body(q) : ''; loadImages();
    }
  });
  // a picture that cannot load becomes a plain link, so the student can still open it
  document.addEventListener('error', e => {
    const t = e.target; if (t?.tagName !== 'IMG' || !t.closest('#list')) return;
    const url = t.closest('a')?.href ?? t.src, d = document.createElement('div'); d.className = 'imgfail';
    d.append('This image could not be loaded. '); const a = document.createElement('a'); a.href = url; a.target = '_blank'; a.rel = 'noopener noreferrer'; a.textContent = 'Open it directly'; d.append(a);
    (t.closest('a') ?? t).replaceWith(d);
  }, true);

  (async () => {
    try { const { viewerData } = await chrome.storage.local.get('viewerData'); if (viewerData?.questions?.length) return load(viewerData); } catch { /* no extension context */ }
    $('empty').hidden = false;
  })();
})();
